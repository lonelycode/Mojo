import tornado.web

#Register your UI Module functions here