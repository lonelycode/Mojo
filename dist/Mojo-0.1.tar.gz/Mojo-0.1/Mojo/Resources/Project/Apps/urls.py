from views import *

urlpatterns = [
    #Place your URL Routes / RequestHandler mappings in here for this app, e.g.
    ('/',      NewInstallHandler),
]
